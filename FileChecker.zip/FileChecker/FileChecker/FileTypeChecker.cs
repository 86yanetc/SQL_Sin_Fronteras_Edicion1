﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileChecker
{
	public interface IFileTypeChecker
	{
		FileType GetFileType(Stream fileContent);
		IEnumerable<FileType> GetFileTypes(Stream stream);
	}
	public abstract class FileTypeMatcher
	{
		public bool Matches(Stream stream, bool resetPosition = true)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}
			if (!stream.CanRead || (stream.Position != 0 && !stream.CanSeek))
			{
				throw new ArgumentException("File contents must be a readable stream", "stream");
			}
			if (stream.Position != 0 && resetPosition)
			{
				stream.Seek(0, SeekOrigin.Begin);
			}

			return MatchesPrivate(stream);
		}

		protected abstract bool MatchesPrivate(Stream stream);
	}
	public class FileType
	{
		private static readonly FileType unknown = new FileType("unknown", string.Empty, null);

		private readonly string name;

		private readonly string extension;

		private readonly FileTypeMatcher fileTypeMatcher;

		public string Name { get { return name; } }

		public string Extension { get { return extension; } }

		public static FileType Unknown { get { return unknown; } }

		public FileType(string name, string extension, FileTypeMatcher matcher)
		{
			this.name = name;
			this.extension = extension;
			this.fileTypeMatcher = matcher;
		}

		public bool Matches(Stream stream)
		{
			return this.fileTypeMatcher == null || this.fileTypeMatcher.Matches(stream);
		}
	}
	public class ExactFileTypeMatcher : FileTypeMatcher
	{
		private readonly byte[] bytes;

		public ExactFileTypeMatcher(IEnumerable<byte> bytes)
		{
			this.bytes = bytes.ToArray();
		}

		protected override bool MatchesPrivate(Stream stream)
		{
			foreach (var b in bytes)
			{
				if (stream.ReadByte() != b)
				{
					return false;
				}
			}

			return true;
		}
	}
	public class FuzzyFileTypeMatcher : FileTypeMatcher
	{
		private readonly byte?[] bytes;

		public FuzzyFileTypeMatcher(IEnumerable<byte?> bytes)
		{
			this.bytes = bytes.ToArray();
		}

		protected override bool MatchesPrivate(Stream stream)
		{
			foreach (var b in this.bytes)
			{
				var c = stream.ReadByte();
				if (c == -1 || (b.HasValue && c != b.Value))
				{
					return false;
				}
			}

			return true;
		}
	}
	public class RangeFileTypeMatcher : FileTypeMatcher
	{
		private readonly FileTypeMatcher matcher;

		private readonly int maximumStartLocation;

		public RangeFileTypeMatcher(FileTypeMatcher matcher, int maximumStartLocation)
		{
			this.matcher = matcher;
			this.maximumStartLocation = maximumStartLocation;
		}

		protected override bool MatchesPrivate(Stream stream)
		{
			for (var i = 0; i < this.maximumStartLocation; i++)
			{
				stream.Position = i;
				if (matcher.Matches(stream, resetPosition: false))
				{
					return true;
				}
			}

			return false;
		}
	}
	public class FileTypeChecker : IFileTypeChecker
	{
		private IList<FileType> knownFileTypes;

		public FileTypeChecker()
		{
			this.knownFileTypes = new List<FileType>
				{
					new FileType("MP3", ".mp3", new ExactFileTypeMatcher(new byte[] {0x49, 0x44, 0x33})),
					new FileType("MP3 CRM", ".mp3 CRM", new ExactFileTypeMatcher(new byte[] {0xFF})),
					new FileType("Microsoft Windows Media Audio/Video File", ".wma",
						new FuzzyFileTypeMatcher(new byte?[] { 0x30, 0x26, 0xB2, 0x75, 0x8E, 0x66, 0xCF, 0x11, 0xA6, 0xD9, 0x00, 0xAA, 0x00, 0x62, 0xCE, 0x6C})),
					new FileType("WAV", ".wav",
						new FuzzyFileTypeMatcher(new byte?[] {0x52, 0x49, 0x46, 0x46, null, null, null, null, 0x57, 0x41, 0x56, 0x45, 0x66, 0x6D, 0x74, 0x20})),
                    // ... Potentially more in future
                };
		}

		public FileTypeChecker(IList<FileType> knownFileTypes)
		{
			this.knownFileTypes = knownFileTypes;
		}

		public FileType GetFileType(Stream fileContent)
		{
			return GetFileTypes(fileContent).FirstOrDefault() ?? FileType.Unknown;
		}

		public IEnumerable<FileType> GetFileTypes(Stream stream)
		{
			return knownFileTypes.Where(fileType => fileType.Matches(stream));
		}
	}
}
