/*
Last update on Tue Jan 25 17:16:56 2022

@author: mvecco
*/

using System.IO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using System;
using System.Configuration;
using Azure;
using Azure.Storage;
using Azure.Storage.Files.Shares;
using Azure.Storage.Files.Shares.Models;
using Azure.Storage.Sas;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Azure.Cosmos;
//using Azure.Cosmos;
using System.Text;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.VisualBasic.FileIO;
using System.Collections.Generic;
using System.Linq;
using System.Dynamic;
using TagLib;

namespace Company.Function
{
    public static class importArchivos
    {
        [FunctionName(nameof(importArchivos))]
        public static async Task<IActionResult> RunAsync(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)]
        HttpRequest req, ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            //Obtencion de datos de blog storage y staging
            string connectionString = Environment.GetEnvironmentVariable("STORAGE_CONNSTRING");
            string stagingShareName = Environment.GetEnvironmentVariable("STAGING_NAME");
            
            //Obtencion de datos desde el head del post
            string shareName = req.Query["share_name"];
            string dirName = req.Query["dir_name"];
            string gpgAudioFileName = req.Query["audio_name"];
            string metadataFileName = req.Query["metadata_file"]; 
            //string fileName = req.Query["batch_name"];
            
            //Obtencion de datos desde el body
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            shareName = shareName ?? data?.share_name;
            dirName = dirName ?? data?.dir_name;
            gpgAudioFileName = gpgAudioFileName ?? data?.audio_name;
            metadataFileName = metadataFileName ?? data?.metadata_file;
            //fileName = fileName ?? data?.batch_name;
            log.LogInformation($"{gpgAudioFileName}");


            //Divido el directorio y creo los directorios "Cargado" y "Error" en base al de pendientes
            string[] splitDirName = dirName.Split("/");
            string cargadoDirName = splitDirName[0]+"/Cargado/"+splitDirName[2]+"/"+splitDirName[3]+"/"+splitDirName[4];
            string errorDirName = splitDirName[0]+"/Error/"+splitDirName[2]+"/"+splitDirName[3]+"/"+splitDirName[4];

            //Saco "gpg" del final del nombre del archivo
            string audioFileName = gpgAudioFileName.Remove(gpgAudioFileName.Length-4);
            log.LogInformation($"{audioFileName}");

            //Obtengo extensión del archivo en base al nombre
            string ext = audioFileName.Substring(audioFileName.Length - 3);
            //Si es el csv de metadata termino la ejecución devolviendo el mensaje "Archivo CSV", si no comienzo la importación
            if(ext == "csv")
            {
                return new OkObjectResult("Archivo CSV");
            }
            else
            {

                //Conexión con el File Share y creacion de los clients de los archivos de audio y metadata
                ShareClient share = new ShareClient(connectionString, stagingShareName);
                ShareDirectoryClient directory = share.GetDirectoryClient(dirName);
                log.LogInformation($"{dirName}");
                ShareFileClient audioFile = directory.GetFileClient(audioFileName);
                ShareFileClient metadataFile = directory.GetFileClient(metadataFileName);

                //Guardo la metadata en un path temporal
                var metadataTempPath = Path.Combine(Path.GetTempPath(),metadataFileName);
                ShareFileDownloadInfo download = metadataFile.Download();
                using (FileStream stream = System.IO.File.OpenWrite(metadataTempPath))
                {
                        download.Content.CopyTo(stream);
                }

                //Guardo el audio en un path tempora
                var audioTempPath = Path.Combine(Path.GetTempPath(),audioFileName);
                ShareFileDownloadInfo audioDownload = audioFile.Download();
                using (FileStream stream = System.IO.File.OpenWrite(audioTempPath))
                {
                        audioDownload.Content.CopyTo(stream);
                }

                //Obtengo la metadata del audio con un csv parser
                string audioId = "";
                string consolidacion = "";
                string formatoOk = "";
                string tipoProcesamiento = "";
                string[] metadataArray = {};
                string[] columnsArray = {};
                using (TextFieldParser csvParser = new TextFieldParser(metadataTempPath))
                {
                    csvParser.CommentTokens = new string[] { "#" };
                    csvParser.SetDelimiters(new string[] { ";" });
                    csvParser.HasFieldsEnclosedInQuotes = true;
                    log.LogInformation($"CSV Parser");

                    // Skip the row with the column names
                    //string[] columns = csvParser.ReadLine();

                    columnsArray = csvParser.ReadFields();
                    int audioIdIndex = Array.FindIndex(columnsArray,i => i == "AUDIO_ETIQUETA_DEL_AUDIO");
                    int consolidacionIdIndex = Array.FindIndex(columnsArray,i => i == "Consolidacion");
                    int procesamientoIdIndex = Array.FindIndex(columnsArray,i => i == "tipoProcesamiento");
                    log.LogInformation($"Indices");
                    //int formatoOkIdIndex = Array.FindIndex(columns,i => i == "Formato_OK");

                    bool foundAudio = false;
                    while (foundAudio == false)
                    {
                    // Read current line fields, pointer moves to the next line.
                        string[] fields = csvParser.ReadFields();
                        audioId = fields[audioIdIndex];
                        if(audioId == audioFileName){
                            consolidacion = fields[consolidacionIdIndex];
                            tipoProcesamiento = fields[procesamientoIdIndex];
                            foundAudio = true;
                            metadataArray = fields;
                            log.LogInformation($"Audio encontrado");
                            log.LogInformation($"{audioId}");
                            log.LogInformation($"{consolidacion}");
                        }
                    }
                }
                
                
                List<string> columns = columnsArray.ToList();
                List<string> metadata = metadataArray.ToList();

                columns.Add("Formato");
                columns.Add("Formato_OK");
                columns.Add("id");
                
                //Obtención de extensión del audio mediante magic numbers
                FileTypeChecker checker = new FileTypeChecker();

                Stream audioFileStream = audioFile.OpenRead();

                log.LogInformation($"Byte: {audioFileStream.ReadByte()}");
                log.LogInformation($"Byte: {audioFileStream.ReadByte()}");
                log.LogInformation($"Byte: {audioFileStream.ReadByte()}");
                log.LogInformation($"Byte: {audioFileStream.ReadByte()}");

                FileType audioExtension = checker.GetFileType(audioFileStream);

                log.LogInformation($"Audio: {audioId}");
                log.LogInformation($"Extensión: {audioExtension.Name.ToString()}");
                
                Random r = new Random();
                int n = r.Next();
                //Creacion de guid para usar como ID en cosmos
                string autoId = Guid.NewGuid().ToString();
                
                //Obtención de duración del audio
                string audioDuration = "";

                TimeSpan minDuration = new TimeSpan(0,0,30);
                string duracionOK = "True";

                //Check de extensión OK
                if((audioExtension.Extension == ".mp3" || audioExtension.Extension == ".mp3 CRM" ||audioExtension.Extension == ".wav" || audioExtension.Extension == ".wma") && (ext == "mp3" || ext == "wav" || ext == "wma" || ext == "MP3"))
                {
                    metadata.Add(audioExtension.Extension);
                    metadata.Add("True");
                    metadata.Add(autoId);
                    formatoOk = "True";
                    var tfile = TagLib.File.Create(audioTempPath);
                    TimeSpan duration = tfile.Properties.Duration;
                    if(duration < minDuration){
                        duracionOK = "False";
                    }
                    else{
                        duracionOK = "True";
                    }
                    audioDuration = duration.ToString(@"hh\:mm\:ss");
                }
                else
                {
                    metadata.Add("Formato inválido");
                    metadata.Add("False");
                    metadata.Add(autoId);
                    formatoOk = "False";
                }

                log.LogInformation($"{audioId}");
                log.LogInformation($"{consolidacion}");
                log.LogInformation($"{formatoOk}");

                //Creación de dict con la metadata
                var metadataDict = columns.Zip(metadata, (k, v) => new { k, v }).ToDictionary(x => x.k, x => x.v);
                //Sumo la info de duración a la metadata
                metadataDict["Duracion"] = audioDuration;

                //Conexión con blob storage
                string blobConnectionString = Environment.GetEnvironmentVariable("BLOB_STORAGE_CONNSTRING");;
                string audiosContainerName = "audios";
                string procesadosContainerName = "audios-procesados";
                string blobName = audioId;
                string filePath = audioTempPath;

                //Conexión con cosmos DB
                string EndpointUrl = Environment.GetEnvironmentVariable("COSMOS_URL");
                string AuthorizationKey = Environment.GetEnvironmentVariable("COSMOS_KEY");
                string DatabaseId = Environment.GetEnvironmentVariable("COSMOS_DB");
                string metadataContainerId = "metadata";
                string metadataErrorContainerId = "metadata-error";

                CosmosClient cosmosClientV2 = new CosmosClient(EndpointUrl, AuthorizationKey);

                BlobServiceClient blobServiceClient = new BlobServiceClient(blobConnectionString);

                //Elección de container en base al tipo de procesamiento
                string containerName ="";
                if(tipoProcesamiento.ToLower() == "parcial"){
                    containerName = procesadosContainerName;
                }
                else{
                    containerName = audiosContainerName;
                }

                //Creacion de los clientes para los containers y los blobs
                BlobContainerClient container = blobServiceClient.GetBlobContainerClient(containerName);

                BlobClient blob = container.GetBlobClient(blobName);

                log.LogInformation($"Blob Client");

                bool audioExiste = blob.Exists();

                log.LogInformation($"{audioExiste}");

                BlobContainerClient procesadoContainer = blobServiceClient.GetBlobContainerClient(procesadosContainerName);

                BlobClient procesadoBlob = procesadoContainer.GetBlobClient(blobName);

                log.LogInformation($"Procesado Blob Client");

                bool procesadoAudioExiste = procesadoBlob.Exists();

                log.LogInformation($"{procesadoAudioExiste}");

                //Conexion con el container dentro de cosmos DB con la metadata y los errores
                Container metadataContainerV2 = cosmosClientV2.GetContainer(DatabaseId, metadataContainerId);
                Container errorMetadataContainerV2 = cosmosClientV2.GetContainer(DatabaseId, metadataErrorContainerId);

                //Comienza carga del audio
                // Si el archivo ya existe se aplica la lógica correspondiente al tipo de procesamiento
                if((audioExiste == true || procesadoAudioExiste == true) && consolidacion.ToLower() == "true" && formatoOk.ToLower() == "true" && duracionOK.ToLower() == "true")
                {
                    log.LogInformation("Existe");
                    var sqlQueryText = "SELECT * FROM c WHERE c.audio_id IN ('"+audioFileName+"')";

                    QueryDefinition queryDefinition = new QueryDefinition(sqlQueryText);

                    List<dynamic> result = new List<dynamic>();
                    var queryable = metadataContainerV2.GetItemLinqQueryable<IDictionary<string, object>>(true);
                    var query = queryable.Where(c => (string)c["audio_id"] == audioFileName);
                    var iterator = query.ToList<dynamic>();
                    log.LogInformation("Query OK");


                    var oldAudioMetadata = (IDictionary<string,object>)iterator[0];
                    string oldTipoProcesamiento = (string)oldAudioMetadata["tipoProcesamiento"];

                    if(oldTipoProcesamiento.ToLower()=="completo"){
                        string transcripcion = (string)oldAudioMetadata["transcripcion"];
                        metadataDict["transcripcion"] = transcripcion;
                    }

                    log.LogInformation($"{oldTipoProcesamiento}");
                    if(tipoProcesamiento.ToLower() == oldTipoProcesamiento.ToLower())
                    {   
                        log.LogInformation("Existe opcion 1");
                        metadataDict["log"] = "El archivo ya existe en blob storage y el tipo de procesamiento definido ya ha sido aplicado";
                        var metadataObject = new ExpandoObject();
                        var dict = new Dictionary<string, string>();
                        log.LogInformation("Dict ok");
                        foreach(var kvp in metadataDict)
                        {
                            (metadataObject as IDictionary<string, object>)[kvp.Key] = kvp.Value;
                        }
                        log.LogInformation("Dict to expando ok");
                        string oldID = (string)oldAudioMetadata["id"];
                        log.LogInformation($"{oldID}");
                        await metadataContainerV2.ReplaceItemAsync<dynamic>(metadataObject,(string)oldAudioMetadata["id"],new Microsoft.Azure.Cosmos.PartitionKey(audioFileName));
                        log.LogInformation($"Item reemplazado");
                        // await metadataContainer.CreateItemAsync<ExpandoObject>(response, new PartitionKey(audioFileName));
                        // log.LogInformation($"Item subido");
                        ShareClient destShare = new ShareClient(connectionString, stagingShareName);
                        log.LogInformation($"File share created");
                        // Get a reference to a directory and create it
                        ShareDirectoryClient destDirectory = destShare.GetDirectoryClient(cargadoDirName);
                        await destDirectory.CreateIfNotExistsAsync();
                        log.LogInformation($"Directory created");
                        // Get a reference to a file and upload it
                        ShareFileClient destFile = destDirectory.GetFileClient(audioFileName);
                        log.LogInformation($"File client created");
                        destFile.Create(audioFileStream.Length);
                        log.LogInformation($"Create");
                        destFile.Upload(audioFileStream);
                        log.LogInformation($"File uploaded");
                        System.IO.File.Delete(metadataTempPath);
                        System.IO.File.Delete(audioTempPath);
                        audioFileStream.Close();
                        return new OkObjectResult("[OK] Audio cargado en: "+cargadoDirName);
                    }
                    else
                    {
                        if(tipoProcesamiento.ToLower() == "parcial" && oldTipoProcesamiento.ToLower() == "completo")
                        {
                            log.LogInformation("Existe opcion 2");
                            metadataDict["log"]= "El archivo ya existe en blob storage y el tipo de procesamiento previamente aplicado es superior al definido para esta importación.";
                            var metadataObject = new ExpandoObject();
                            var dict = new Dictionary<string, string>();
                            
                            foreach(var kvp in metadataDict)
                            {
                                (metadataObject as IDictionary<string, object>)[kvp.Key] = kvp.Value;
                            }
                            string oldID = (string)oldAudioMetadata["id"];
                            log.LogInformation($"{oldID}");
                            await metadataContainerV2.ReplaceItemAsync<dynamic>(metadataObject,(string)oldAudioMetadata["id"],new Microsoft.Azure.Cosmos.PartitionKey(audioFileName));
                            log.LogInformation($"Item reemplazado");
                            ShareClient destShare = new ShareClient(connectionString, stagingShareName);
                            log.LogInformation($"File share created");
                            // Get a reference to a directory and create it
                            ShareDirectoryClient destDirectory = destShare.GetDirectoryClient(cargadoDirName);
                            await destDirectory.CreateIfNotExistsAsync();
                            log.LogInformation($"Directory created");
                            // Get a reference to a file and upload it
                            ShareFileClient destFile = destDirectory.GetFileClient(audioFileName);
                            log.LogInformation($"File client created");
                            destFile.Create(audioFileStream.Length);
                            log.LogInformation($"Create");
                            destFile.Upload(audioFileStream);
                            log.LogInformation($"File uploaded");
                            System.IO.File.Delete(metadataTempPath);
                            System.IO.File.Delete(audioTempPath);
                            audioFileStream.Close();
                            return new OkObjectResult("[OK] Audio cargado en: "+cargadoDirName);
                        }
                        else
                        {
                            if(tipoProcesamiento.ToLower() == "completo" && oldTipoProcesamiento.ToLower() == "parcial")
                            {
                                log.LogInformation("Existe opcion 3");
                                metadataDict["log"]= "El archivo ya existe en blob storage pero el tipo de procesamiento definido no ha sido aplicado. Se cargará nuevamente el archivo para su procesamiento.";
                                var metadataObject = new ExpandoObject();
                                var dict = new Dictionary<string, string>();
                                
                                foreach(var kvp in metadataDict)
                                {
                                    (metadataObject as IDictionary<string, object>)[kvp.Key] = kvp.Value;
                                }
                                string oldID = (string)oldAudioMetadata["id"];
                                log.LogInformation($"{oldID}");
                                await metadataContainerV2.ReplaceItemAsync<dynamic>(metadataObject,(string)oldAudioMetadata["id"],new Microsoft.Azure.Cosmos.PartitionKey(audioFileName));
                                log.LogInformation($"Item reemplazado");
                                ShareClient destShare = new ShareClient(connectionString, stagingShareName);
                                log.LogInformation($"File share created");
                                // Get a reference to a directory and create it
                                ShareDirectoryClient destDirectory = destShare.GetDirectoryClient(cargadoDirName);
                                await destDirectory.CreateIfNotExistsAsync();
                                log.LogInformation($"Directory created");
                                // Get a reference to a file and upload it
                                ShareFileClient destFile = destDirectory.GetFileClient(audioFileName);
                                log.LogInformation($"File client created");
                                destFile.Create(audioFileStream.Length);
                                log.LogInformation($"Create");
                                destFile.Upload(audioFileStream);
                                log.LogInformation($"File uploaded");
                                BlobContainerClient audiosContainer = blobServiceClient.GetBlobContainerClient(audiosContainerName);
                                BlobClient newBlob = container.GetBlobClient(blobName);
                                newBlob.DeleteIfExists();
                                log.LogInformation($"Blob anterior borrado");
                                newBlob.Upload(audioTempPath);
                                log.LogInformation($"Blob uploaded");
                                System.IO.File.Delete(metadataTempPath);
                                System.IO.File.Delete(audioTempPath);
                                audioFileStream.Close();
                            return new OkObjectResult("[OK] Audio cargado en: "+cargadoDirName);
                            }
                        }
                    }
                }
                else
                {
                    //Si el audio no existe se realizan checks de formato, consolidación y duración. 
                    //Si esta todo OK se carga en el directorio "Cargados", en caso contrario se carga en el directorio "Error" y se loggea el error correspondiente.
                    log.LogInformation("No existe");
                    if(consolidacion.ToLower() == "true" && formatoOk.ToLower() == "true"&& duracionOK.ToLower() == "true")
                    {
                        log.LogInformation("No existe, todo OK");
                        var metadataObject = new ExpandoObject();
                        var dict = new Dictionary<string, string>();
                        
                        foreach(var kvp in metadataDict)
                        {
                            (metadataObject as IDictionary<string, object>)[kvp.Key] = kvp.Value;
                        }
                        await metadataContainerV2.CreateItemAsync<dynamic>(metadataObject);//, new PartitionKey(audioFileName));
                        log.LogInformation($"Item subido");
                        ShareClient destShare = new ShareClient(connectionString, stagingShareName);
                        log.LogInformation($"File share created");
                        // Get a reference to a directory and create it
                        ShareDirectoryClient destDirectory = destShare.GetDirectoryClient(cargadoDirName);
                        await destDirectory.CreateIfNotExistsAsync();
                        log.LogInformation($"Directory created");
                        // Get a reference to a file and upload it
                        ShareFileClient destFile = destDirectory.GetFileClient(audioFileName);
                        log.LogInformation($"File client created");
                        destFile.Create(audioFileStream.Length);
                        log.LogInformation($"Create");
                        destFile.Upload(audioFileStream);
                        log.LogInformation($"File uploaded");
                        blob.Upload(audioTempPath);
                        log.LogInformation($"Blob uploaded");
                        System.IO.File.Delete(metadataTempPath);
                        System.IO.File.Delete(audioTempPath);
                        audioFileStream.Close();
                        return new OkObjectResult("[OK] Audio cargado en: "+cargadoDirName);
                    }
                    else
                    {
                        if(consolidacion.ToLower() == "true" && formatoOk.ToLower() == "false" && duracionOK.ToLower() == "true")
                        {
                            log.LogInformation("No existe, consolidacion OK");
                            metadataDict["log"]= "El archivo no posee un formato admitido.";
                            log.LogInformation("Log");
                            var metadataObject = new ExpandoObject();
                            log.LogInformation("Expando");
                            var dict = new Dictionary<string, string>();
                            log.LogInformation("Dict");
                            foreach(var kvp in metadataDict)
                            {
                                (metadataObject as IDictionary<string, object>)[kvp.Key] = kvp.Value;
                            }
                            log.LogInformation("Data to expando");
                            log.LogInformation($"{autoId}");
                            await errorMetadataContainerV2.CreateItemAsync<dynamic>(metadataObject);//, new PartitionKey(audioFileName));
                            log.LogInformation($"Item subido");
                            ShareClient destShare = new ShareClient(connectionString, stagingShareName);
                            log.LogInformation($"File share created");
                            // Get a reference to a directory and create it
                            ShareDirectoryClient destDirectory = destShare.GetDirectoryClient(errorDirName);
                            await destDirectory.CreateIfNotExistsAsync();
                            log.LogInformation($"Directory created");
                            // Get a reference to a file and upload it
                            ShareFileClient destFile = destDirectory.GetFileClient(audioFileName);
                            log.LogInformation($"File client created");
                            destFile.Create(audioFileStream.Length);
                            log.LogInformation($"Create");
                            destFile.Upload(audioFileStream);
                            log.LogInformation($"File uploaded");
                            System.IO.File.Delete(metadataTempPath);
                            System.IO.File.Delete(audioTempPath);
                            audioFileStream.Close();
                            return new OkObjectResult("[ERROR] Audio cargado en: "+errorDirName);
                        }
                        else
                        {
                            if(consolidacion.ToLower() == "false" && formatoOk.ToLower() == "true" && duracionOK.ToLower() == "true")
                            {
                                log.LogInformation("No existe, formato OK");
                                metadataDict["log"]= "Error de consolidación.";
                                var metadataObject = new ExpandoObject();
                                var dict = new Dictionary<string, string>();
                                
                                foreach(var kvp in metadataDict)
                                {
                                    (metadataObject as IDictionary<string, object>)[kvp.Key] = kvp.Value;
                                }
                                await errorMetadataContainerV2.CreateItemAsync<dynamic>(metadataObject);//, new PartitionKey(audioFileName));
                                log.LogInformation($"Item subido");
                                ShareClient destShare = new ShareClient(connectionString, stagingShareName);
                                log.LogInformation($"File share created");
                                ShareDirectoryClient destDirectory = destShare.GetDirectoryClient(errorDirName);
                                await destDirectory.CreateIfNotExistsAsync();
                                log.LogInformation($"Directory created");
                                // Get a reference to a file and upload it
                                ShareFileClient destFile = destDirectory.GetFileClient(audioFileName);
                                log.LogInformation($"File client created");
                                destFile.Create(audioFileStream.Length);
                                log.LogInformation($"Create");
                                destFile.Upload(audioFileStream);
                                log.LogInformation($"File uploaded");
                                System.IO.File.Delete(metadataTempPath);
                                System.IO.File.Delete(audioTempPath);
                                audioFileStream.Close();
                                return new OkObjectResult("[ERROR] Audio cargado en: "+errorDirName);
                            }
                            else
                            {
                                if(consolidacion.ToLower() == "true" && formatoOk.ToLower() == "true" && duracionOK.ToLower() == "false")
                                {
                                    log.LogInformation("No existe, formato OK");
                                    metadataDict["log"]= "No supera la duracion minima requerida.";
                                    var metadataObject = new ExpandoObject();
                                    var dict = new Dictionary<string, string>();
                                    
                                    foreach(var kvp in metadataDict)
                                    {
                                        (metadataObject as IDictionary<string, object>)[kvp.Key] = kvp.Value;
                                    }
                                    await errorMetadataContainerV2.CreateItemAsync<dynamic>(metadataObject);//, new PartitionKey(audioFileName));
                                    log.LogInformation($"Item subido");
                                    ShareClient destShare = new ShareClient(connectionString, stagingShareName);
                                    log.LogInformation($"File share created");
                                    ShareDirectoryClient destDirectory = destShare.GetDirectoryClient(errorDirName);
                                    await destDirectory.CreateIfNotExistsAsync();
                                    log.LogInformation($"Directory created");
                                    // Get a reference to a file and upload it
                                    ShareFileClient destFile = destDirectory.GetFileClient(audioFileName);
                                    log.LogInformation($"File client created");
                                    destFile.Create(audioFileStream.Length);
                                    log.LogInformation($"Create");
                                    destFile.Upload(audioFileStream);
                                    log.LogInformation($"File uploaded");
                                    System.IO.File.Delete(metadataTempPath);
                                    System.IO.File.Delete(audioTempPath);
                                    audioFileStream.Close();
                                    return new OkObjectResult("[ERROR] Audio cargado en: "+errorDirName);
                                }
                                else
                                {
                                    if(consolidacion.ToLower() == "false" && formatoOk.ToLower() == "false" && duracionOK.ToLower() == "true")
                                    {
                                        log.LogInformation("No existe, formato OK");
                                        metadataDict["log"]= "Error de formato y consolidación.";
                                        var metadataObject = new ExpandoObject();
                                        var dict = new Dictionary<string, string>();
                                        
                                        foreach(var kvp in metadataDict)
                                        {
                                            (metadataObject as IDictionary<string, object>)[kvp.Key] = kvp.Value;
                                        }
                                        await errorMetadataContainerV2.CreateItemAsync<dynamic>(metadataObject);//, new PartitionKey(audioFileName));
                                        log.LogInformation($"Item subido");
                                        ShareClient destShare = new ShareClient(connectionString, stagingShareName);
                                        log.LogInformation($"File share created");
                                        ShareDirectoryClient destDirectory = destShare.GetDirectoryClient(errorDirName);
                                        await destDirectory.CreateIfNotExistsAsync();
                                        log.LogInformation($"Directory created");
                                        // Get a reference to a file and upload it
                                        ShareFileClient destFile = destDirectory.GetFileClient(audioFileName);
                                        log.LogInformation($"File client created");
                                        destFile.Create(audioFileStream.Length);
                                        log.LogInformation($"Create");
                                        destFile.Upload(audioFileStream);
                                        log.LogInformation($"File uploaded");
                                        audioFileStream.Close();
                                        System.IO.File.Delete(metadataTempPath);
                                        System.IO.File.Delete(audioTempPath);
                                        return new OkObjectResult("[ERROR] Audio cargado en: "+errorDirName);
                                    }
                                    else
                                    {
                                        if(consolidacion.ToLower() == "true" && formatoOk.ToLower() == "false" && duracionOK.ToLower() == "false")
                                        {
                                            log.LogInformation("No existe, formato OK");
                                            metadataDict["log"]= "Error de formato y duración.";
                                            var metadataObject = new ExpandoObject();
                                            var dict = new Dictionary<string, string>();
                                            
                                            foreach(var kvp in metadataDict)
                                            {
                                                (metadataObject as IDictionary<string, object>)[kvp.Key] = kvp.Value;
                                            }
                                            await errorMetadataContainerV2.CreateItemAsync<dynamic>(metadataObject);//, new PartitionKey(audioFileName));
                                            log.LogInformation($"Item subido");
                                            ShareClient destShare = new ShareClient(connectionString, stagingShareName);
                                            log.LogInformation($"File share created");
                                            ShareDirectoryClient destDirectory = destShare.GetDirectoryClient(errorDirName);
                                            await destDirectory.CreateIfNotExistsAsync();
                                            log.LogInformation($"Directory created");
                                            // Get a reference to a file and upload it
                                            ShareFileClient destFile = destDirectory.GetFileClient(audioFileName);
                                            log.LogInformation($"File client created");
                                            destFile.Create(audioFileStream.Length);
                                            log.LogInformation($"Create");
                                            destFile.Upload(audioFileStream);
                                            log.LogInformation($"File uploaded");
                                            System.IO.File.Delete(metadataTempPath);
                                            System.IO.File.Delete(audioTempPath);
                                            audioFileStream.Close();
                                            return new OkObjectResult("[ERROR] Audio cargado en: "+errorDirName);
                                        }
                                        else
                                        {
                                            if(consolidacion.ToLower() == "false" && formatoOk.ToLower() == "true" && duracionOK.ToLower() == "false")
                                            {
                                                log.LogInformation("No existe, formato OK");
                                                metadataDict["log"]= "Error de consolidación y duración.";
                                                var metadataObject = new ExpandoObject();
                                                var dict = new Dictionary<string, string>();
                                                
                                                foreach(var kvp in metadataDict)
                                                {
                                                    (metadataObject as IDictionary<string, object>)[kvp.Key] = kvp.Value;
                                                }
                                                await errorMetadataContainerV2.CreateItemAsync<dynamic>(metadataObject);//, new PartitionKey(audioFileName));
                                                log.LogInformation($"Item subido");
                                                ShareClient destShare = new ShareClient(connectionString, stagingShareName);
                                                log.LogInformation($"File share created");
                                                ShareDirectoryClient destDirectory = destShare.GetDirectoryClient(errorDirName);
                                                await destDirectory.CreateIfNotExistsAsync();
                                                log.LogInformation($"Directory created");
                                                // Get a reference to a file and upload it
                                                ShareFileClient destFile = destDirectory.GetFileClient(audioFileName);
                                                log.LogInformation($"File client created");
                                                destFile.Create(audioFileStream.Length);
                                                log.LogInformation($"Create");
                                                destFile.Upload(audioFileStream);
                                                log.LogInformation($"File uploaded");
                                                System.IO.File.Delete(metadataTempPath);
                                                System.IO.File.Delete(audioTempPath);
                                                audioFileStream.Close();
                                                return new OkObjectResult("[ERROR] Audio cargado en: "+errorDirName);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                System.IO.File.Delete(metadataTempPath);
                System.IO.File.Delete(audioTempPath);
                audioFileStream.Close();
                return new OkObjectResult("Ok");
            }
        }
    }
    //Funciones para obtensión de formato mediante magic numbers. NO TOCAR
    public interface IFileTypeChecker
    {
        FileType GetFileType(Stream fileContent);
        IEnumerable<FileType> GetFileTypes(Stream stream);
    }
    public abstract class FileTypeMatcher
    {
        public bool Matches(Stream stream, bool resetPosition = true)
        {
            if (stream == null)
            {
                throw new ArgumentNullException("stream");
            }
            if (!stream.CanRead || (stream.Position != 0 && !stream.CanSeek))
            {
                throw new ArgumentException("File contents must be a readable stream", "stream");
            }
            if (stream.Position != 0 && resetPosition)
            {
                stream.Seek(0, SeekOrigin.Begin);
            }

            return MatchesPrivate(stream);
        }

        protected abstract bool MatchesPrivate(Stream stream);
    }
    public class FileType
    {
        private static readonly FileType unknown = new FileType("unknown", string.Empty, null);

        private readonly string name;

        private readonly string extension;

        private readonly FileTypeMatcher fileTypeMatcher;

        public string Name { get { return name; } }

        public string Extension { get { return extension; } }

        public static FileType Unknown { get { return unknown; } }

        public FileType(string name, string extension, FileTypeMatcher matcher)
        {
            this.name = name;
            this.extension = extension;
            this.fileTypeMatcher = matcher;
        }

        public bool Matches(Stream stream)
        {
            return this.fileTypeMatcher == null || this.fileTypeMatcher.Matches(stream);
        }
    }  
    public class ExactFileTypeMatcher : FileTypeMatcher
    {
        private readonly byte[] bytes;

        public ExactFileTypeMatcher(IEnumerable<byte> bytes)
        {
            this.bytes = bytes.ToArray();
        }

        protected override bool MatchesPrivate(Stream stream)
        {
            foreach (var b in bytes)
            {
                if (stream.ReadByte() != b)
                {
                    return false;
                }
            }

            return true;
        }
    }
    public class FuzzyFileTypeMatcher : FileTypeMatcher
    {
        private readonly byte?[] bytes;

        public FuzzyFileTypeMatcher(IEnumerable<byte?> bytes)
        {
            this.bytes = bytes.ToArray();
        }

        protected override bool MatchesPrivate(Stream stream)
        {
            foreach (var b in this.bytes)
            {
                var c = stream.ReadByte();
                if (c == -1 || (b.HasValue && c != b.Value))
                {
                    return false;
                }
            }

            return true;
        }
    }
        public class RangeFileTypeMatcher : FileTypeMatcher
        {
        private readonly FileTypeMatcher matcher;

        private readonly int maximumStartLocation;

        public RangeFileTypeMatcher(FileTypeMatcher matcher, int maximumStartLocation)
        {
            this.matcher = matcher;
            this.maximumStartLocation = maximumStartLocation;
        }

        protected override bool MatchesPrivate(Stream stream)
        {
            for (var i = 0; i < this.maximumStartLocation; i++)
            {
                stream.Position = i;
                if (matcher.Matches(stream, resetPosition: false))
                {
                    return true;
                }
            }

            return false;
        }
    }
    public class FileTypeChecker : IFileTypeChecker
    {
        private IList<FileType> knownFileTypes;

        public FileTypeChecker()
        {
            this.knownFileTypes = new List<FileType>
                {
                    new FileType("MP3", ".mp3", new ExactFileTypeMatcher(new byte[] {0x49, 0x44, 0x33})),
                    new FileType("MP3 CRM", ".mp3 CRM", new ExactFileTypeMatcher(new byte[] {0xFF})),
                    new FileType("Microsoft Windows Media Audio/Video File", ".wma",
                        new FuzzyFileTypeMatcher(new byte?[] { 0x30, 0x26, 0xB2, 0x75, 0x8E, 0x66, 0xCF, 0x11, 0xA6, 0xD9, 0x00, 0xAA, 0x00, 0x62, 0xCE, 0x6C})),
                    new FileType("WAV", ".wav",
                        new FuzzyFileTypeMatcher(new byte?[] {0x52, 0x49, 0x46, 0x46, null, null, null, null, 0x57, 0x41, 0x56, 0x45, 0x66, 0x6D, 0x74, 0x20})),
                    // ... Potentially more in future
                };
        }

        public FileTypeChecker(IList<FileType> knownFileTypes)
        {
            this.knownFileTypes = knownFileTypes;
        }

        public FileType GetFileType(Stream fileContent)
        {
            return GetFileTypes(fileContent).FirstOrDefault() ?? FileType.Unknown;
        }

        public IEnumerable<FileType> GetFileTypes(Stream stream)
        {
            return knownFileTypes.Where(fileType => fileType.Matches(stream));
        }
    }
}   