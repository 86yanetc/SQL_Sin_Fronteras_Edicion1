﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace FileChecker
{
	public static class FileChecker
	{
		public static void CheckFile(string path)
		{
			FileTypeChecker checker = new FileTypeChecker();

			Stream audioFileStream = new StreamReader(path).BaseStream;

			FileType audioExtension = checker.GetFileType(audioFileStream);


			string ext = Path.GetExtension(path);
			if ((audioExtension.Extension == ".mp3" || audioExtension.Extension == ".mp3 CRM" || audioExtension.Extension == ".wav" || audioExtension.Extension == ".wma") && (ext == "mp3" || ext == "wav" || ext == "wma" || ext == "MP3"))
			{
				Console.WriteLine("Archivo correcto");
			}
			else
			{
				Console.WriteLine("Archivo incorrecto");
			}
		}
	}
}
