﻿var path = Path.Combine("C:", "Audio", "audio.mp3");
FileChecker.FileChecker.CheckFile(path);
